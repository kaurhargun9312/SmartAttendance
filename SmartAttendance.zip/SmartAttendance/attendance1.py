import cv2
import face_recognition
import os
import numpy as np
from datetime import datetime

# Define base directory for the project
base_path = "C:/SmartAttendance"

# Set paths for known face images and attendance CSV file
known_faces = os.path.join(base_path, "known_faces")
attendance = os.path.join(base_path, "attendance.csv")

# Lists to store loaded face images and corresponding user names
faces = []
u_names = []

# Load and store face images along with their names
for filename in os.listdir(known_faces):
    img_path = os.path.join(known_faces, filename)
    img = cv2.imread(img_path)

    if img is not None:
        faces.append(img)
        u_names.append(os.path.splitext(filename)[0])  # Extract name without file extension

# Function to encode all loaded face images
def encode_faces(faces):
    encodefaces = []
    for img in faces:
        # Convert image from BGR (OpenCV format) to RGB (face_recognition format)
        imgrgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        imgs = face_recognition.face_encodings(imgrgb)
        if imgs:
            encodefaces.append(imgs[0])  # Store the first face encoding
    return encodefaces

# Encode all known faces
encode_knownfaces = encode_faces(faces)

# Function to mark attendance into a CSV file, only once per person per day
def markattendance(names):
    current_date = datetime.now().strftime("%Y-%m-%d")
    current_time = datetime.now().strftime("%H:%M:%S")

    # Create attendance file if it doesn't exist
    if not os.path.exists(attendance):
        with open(attendance, "w") as f:
            f.write("name,time,date\n")

    already_marked = False

    # Read the existing attendance records
    with open(attendance, "r") as file:
        lines = file.readlines()
        for line in lines:
            line_parts = line.strip().split(",")
            if len(line_parts) >= 3:
                recorded_name = line_parts[0].strip()
                recorded_date = line_parts[2].strip()
                # Check if the same person has already been marked today
                if recorded_name == names and recorded_date == current_date:
                    already_marked = True
                    break

    # Write the attendance entry if not already marked for today
    if not already_marked:
        with open(attendance, "a") as file:
            file.write(f"{names},{current_time},{current_date}\n")

# Start capturing video from the webcam
cap = cv2.VideoCapture(0)

while True:
    success, frames = cap.read()

    if not success:
        print("Failed to capture frame from webcam. Exiting...")
        break

    # Resize frame for faster processing
    small_img = cv2.resize(frames, (0, 0), fx=0.25, fy=0.25)
    img_rgb = cv2.cvtColor(small_img, cv2.COLOR_BGR2RGB)

    # Detect faces in the frame and encode them
    face_inframe = face_recognition.face_locations(img_rgb)
    encode_faceinframe = face_recognition.face_encodings(img_rgb, face_inframe)

    for encodefaces, facedis in zip(encode_faceinframe, face_inframe):
        # Compare detected face with known faces
        matches = face_recognition.compare_faces(encode_knownfaces, encodefaces)
        face_dist = face_recognition.face_distance(encode_knownfaces, encodefaces)
        best_match = np.argmin(face_dist)

        if matches[best_match]:
            name = u_names[best_match].upper()
            y1, x2, y2, x1 = facedis
            # Scale coordinates back to original size
            y1, x2, y2, x1 = y1 * 4, x2 * 4, y2 * 4, x1 * 4

            # Draw rectangle and name on the face
            cv2.rectangle(frames, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frames, name, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
            
            # Mark attendance in CSV
            markattendance(name)

    # Display the webcam feed
    cv2.imshow('Webcam - Press Q to Quit', frames)

    # Exit on pressing 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release webcam and close OpenCV windows
cap.release()
cv2.destroyAllWindows()
